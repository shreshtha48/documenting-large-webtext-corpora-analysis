# Machine-generated text in post-LLM C4

Documents (>= 100 words): 2019 C4: 5000, CC-MAIN-2024-10: 27458, CC-MAIN-2024-51: 22190

## Lower bound on the LLM-processed share (marker words)

| corpus | compared_with | words | rate_now_pct | rate_then_pct | lower_bound_llm_share_pct | ci_lo | ci_hi |
|---|---|---|---|---|---|---|---|
| CC-MAIN-2024-10 | 2019 C4 | ANY MARKER | 7.63 | 4.58 | 3.19 | 2.38 | 3.94 |
| CC-MAIN-2024-10 | 2019 C4 | ANY CONTROL | 70.79 | 69.2 | 5.17 | 0.51 | 9.98 |
| CC-MAIN-2024-51 | 2019 C4 | ANY MARKER | 9.7 | 4.58 | 5.36 | 4.51 | 6.16 |
| CC-MAIN-2024-51 | 2019 C4 | ANY CONTROL | 69.56 | 69.2 | 1.18 | -3.77 | 6.11 |
| CC-MAIN-2024-51 | CC-MAIN-2024-10 | ANY MARKER | 9.7 | 7.63 | 2.24 | 1.5 | 3.1 |
| CC-MAIN-2024-51 | CC-MAIN-2024-10 | ANY CONTROL | 69.56 | 70.79 | -4.21 | -8.42 | -0.06 |

## Marker / control document rates

| corpus | word | kind | docs | doc_rate_pct | ci_lo | ci_hi |
|---|---|---|---|---|---|---|
| 2019 C4 | ANY MARKER | marker | 5000 | 4.58 | 4.03 | 5.18 |
| 2019 C4 | ANY CONTROL | control | 5000 | 69.2 | 67.84 | 70.37 |
| CC-MAIN-2024-10 | ANY MARKER | marker | 27458 | 7.63 | 7.17 | 8.1 |
| CC-MAIN-2024-10 | ANY CONTROL | control | 27458 | 70.79 | 69.99 | 71.59 |
| CC-MAIN-2024-51 | ANY MARKER | marker | 22190 | 9.7 | 9.11 | 10.29 |
| CC-MAIN-2024-51 | ANY CONTROL | control | 22190 | 69.56 | 68.67 | 70.44 |

## Binoculars: share flagged (threshold set on 2019 C4)

| fpr_on_2019_pct | threshold | corpus | docs_scored | flagged_pct | ci_lo | ci_hi | excess_over_2019_pct |
|---|---|---|---|---|---|---|---|
| 1 | 0.9 | 2019 C4 | 3538 | 1.02 | 0.71 | 1.36 | 0.02 |
| 1 | 0.9 | CC-MAIN-2024-10 | 16797 | 1.23 | 1.0 | 1.46 | 0.23 |
| 1 | 0.9 | CC-MAIN-2024-51 | 13896 | 1.32 | 1.05 | 1.6 | 0.32 |
| 5 | 0.94 | 2019 C4 | 3538 | 5.0 | 4.28 | 5.77 | 0.0 |
| 5 | 0.94 | CC-MAIN-2024-10 | 16797 | 5.48 | 5.01 | 6.01 | 0.48 |
| 5 | 0.94 | CC-MAIN-2024-51 | 13896 | 5.89 | 5.31 | 6.46 | 0.89 |

## Do the two measures agree?

| corpus | binoculars | docs | any_marker_pct | ci_lo | ci_hi |
|---|---|---|---|---|---|
| 2019 C4 | flagged | 36 | 5.56 | 0.0 | 13.89 |
| 2019 C4 | not flagged | 3502 | 4.34 | 3.69 | 4.99 |
| CC-MAIN-2024-10 | flagged | 207 | 7.73 | 2.93 | 13.53 |
| CC-MAIN-2024-10 | not flagged | 16590 | 6.05 | 5.56 | 6.58 |
| CC-MAIN-2024-51 | flagged | 184 | 6.52 | 2.15 | 12.09 |
| CC-MAIN-2024-51 | not flagged | 13712 | 7.73 | 7.09 | 8.39 |

## Flag rate by group (1% threshold; 2019 rows are false positives)

| corpus | group | docs | flagged_pct | ci_lo | ci_hi |
|---|---|---|---|---|---|
| 2019 C4 | Jewish | 90 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | Arab | 92 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | Asian | 115 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | Caucasian | 20 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | European | 168 | 2.38 | 0.6 | 4.76 |
| 2019 C4 | White | 190 | 0.53 | 0.0 | 1.6 |
| 2019 C4 | Alaskan | 56 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | Hispanic | 67 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | Native American | 66 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | South-American | 63 | 1.59 | 0.0 | 4.76 |
| 2019 C4 | African-American | 86 | 1.16 | 0.0 | 3.49 |
| 2019 C4 | Latino | 63 | 1.59 | 0.0 | 4.84 |
| 2019 C4 | Middle-Eastern | 73 | 4.11 | 0.0 | 9.59 |
| 2019 C4 | Black | 172 | 0.58 | 0.0 | 1.74 |
| 2019 C4 | African | 177 | 0.0 | 0.0 | 0.0 |
| 2019 C4 | ANY GROUP | 1216 | 0.82 | 0.33 | 1.33 |
| CC-MAIN-2024-10 | Jewish | 32 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | Arab | 42 | 9.52 | 0.0 | 23.81 |
| CC-MAIN-2024-10 | Asian | 86 | 4.65 | 0.0 | 11.63 |
| CC-MAIN-2024-10 | Caucasian | 4 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | European | 326 | 0.61 | 0.0 | 1.86 |
| CC-MAIN-2024-10 | White | 184 | 1.09 | 0.0 | 3.33 |
| CC-MAIN-2024-10 | Alaskan | 4 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | Hispanic | 10 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | Native American | 8 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | South-American | 2 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | African-American | 10 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | Latino | 2 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-10 | Black | 208 | 1.92 | 0.0 | 4.81 |
| CC-MAIN-2024-10 | African | 102 | 1.96 | 0.0 | 5.88 |
| CC-MAIN-2024-10 | ANY GROUP | 942 | 1.49 | 0.43 | 2.77 |
| CC-MAIN-2024-51 | Jewish | 24 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Arab | 22 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Asian | 88 | 2.27 | 0.0 | 6.98 |
| CC-MAIN-2024-51 | European | 198 | 1.01 | 0.0 | 4.0 |
| CC-MAIN-2024-51 | White | 166 | 1.2 | 0.0 | 3.61 |
| CC-MAIN-2024-51 | Alaskan | 4 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Hispanic | 10 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Native American | 12 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | South-American | 8 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | African-American | 10 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Latino | 2 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Middle-Eastern | 6 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | Black | 240 | 0.0 | 0.0 | 0.0 |
| CC-MAIN-2024-51 | African | 74 | 5.41 | 0.0 | 13.51 |
| CC-MAIN-2024-51 | ANY GROUP | 810 | 1.23 | 0.25 | 2.45 |

## Tone

| corpus | subset | unit | measure | docs | docs_with_group_paragraphs | positivity | ci_lo | ci_hi |
|---|---|---|---|---|---|---|---|---|
| 2019 C4 | Binoculars flagged (1% FPR) | document | SocialSent | 36 | 2 | 93.65 | 79.49 | 97.93 |
| 2019 C4 | Binoculars flagged (1% FPR) | document | VADER | 36 | 2 | 84.57 | 78.46 | 89.72 |
| 2019 C4 | Binoculars flagged (1% FPR) | document | UnQover | 36 | 2 | 100.0 | 100.0 | 100.0 |
| 2019 C4 | Binoculars flagged (1% FPR) | document | RoBERTa | 36 | 2 | 89.23 | 81.2 | 95.14 |
| 2019 C4 | Binoculars flagged (1% FPR) | group paragraphs | SocialSent | 36 | 2 | 100.0 | 100.0 | 100.0 |
| 2019 C4 | Binoculars flagged (1% FPR) | group paragraphs | VADER | 36 | 2 | 100.0 | 100.0 | 100.0 |
| 2019 C4 | Binoculars flagged (1% FPR) | group paragraphs | UnQover | 36 | 2 | nan | nan | nan |
| 2019 C4 | Binoculars not flagged | document | SocialSent | 4964 | 388 | 78.49 | 77.34 | 79.51 |
| 2019 C4 | Binoculars not flagged | document | VADER | 4964 | 388 | 75.69 | 74.99 | 76.36 |
| 2019 C4 | Binoculars not flagged | document | UnQover | 4964 | 388 | 83.55 | 82.01 | 85.08 |
| 2019 C4 | Binoculars not flagged | document | RoBERTa | 4964 | 388 | 82.38 | 81.46 | 83.4 |
| 2019 C4 | Binoculars not flagged | group paragraphs | SocialSent | 4964 | 388 | 71.45 | 64.19 | 78.24 |
| 2019 C4 | Binoculars not flagged | group paragraphs | VADER | 4964 | 388 | 69.89 | 64.92 | 74.76 |
| 2019 C4 | Binoculars not flagged | group paragraphs | UnQover | 4964 | 388 | 75.81 | 64.21 | 85.25 |
| 2019 C4 | has marker word | document | SocialSent | 229 | 27 | 85.17 | 81.48 | 88.39 |
| 2019 C4 | has marker word | document | VADER | 229 | 27 | 81.87 | 78.84 | 84.76 |
| 2019 C4 | has marker word | document | UnQover | 229 | 27 | 88.21 | 82.08 | 93.78 |
| 2019 C4 | has marker word | document | RoBERTa | 229 | 27 | 91.37 | 88.24 | 93.85 |
| 2019 C4 | has marker word | group paragraphs | SocialSent | 229 | 27 | 76.19 | 50.0 | 96.15 |
| 2019 C4 | has marker word | group paragraphs | VADER | 229 | 27 | 85.34 | 73.47 | 93.24 |
| 2019 C4 | has marker word | group paragraphs | UnQover | 229 | 27 | 77.78 | 42.86 | 100.0 |
| 2019 C4 | no marker word | document | SocialSent | 4771 | 363 | 78.3 | 77.19 | 79.45 |
| 2019 C4 | no marker word | document | VADER | 4771 | 363 | 75.4 | 74.7 | 76.15 |
| 2019 C4 | no marker word | document | UnQover | 4771 | 363 | 83.36 | 81.66 | 84.96 |
| 2019 C4 | no marker word | document | RoBERTa | 4771 | 363 | 81.91 | 80.86 | 82.84 |
| 2019 C4 | no marker word | group paragraphs | SocialSent | 4771 | 363 | 71.21 | 64.33 | 77.55 |
| 2019 C4 | no marker word | group paragraphs | VADER | 4771 | 363 | 69.25 | 64.6 | 74.04 |
| 2019 C4 | no marker word | group paragraphs | UnQover | 4771 | 363 | 75.71 | 63.0 | 85.46 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | document | SocialSent | 207 | 14 | 86.16 | 76.81 | 93.23 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | document | VADER | 207 | 14 | 79.22 | 73.59 | 84.4 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | document | UnQover | 207 | 14 | 90.91 | 82.28 | 97.37 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | document | RoBERTa | 207 | 14 | 86.94 | 80.01 | 92.26 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | group paragraphs | SocialSent | 207 | 14 | 90.91 | 90.0 | 100.0 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | group paragraphs | VADER | 207 | 14 | 100.0 | 100.0 | 100.0 |
| CC-MAIN-2024-10 | Binoculars flagged (1% FPR) | group paragraphs | UnQover | 207 | 14 | nan | nan | nan |
| CC-MAIN-2024-10 | Binoculars not flagged | document | SocialSent | 27251 | 2524 | 79.17 | 78.46 | 79.87 |
| CC-MAIN-2024-10 | Binoculars not flagged | document | VADER | 27251 | 2524 | 78.31 | 77.92 | 78.73 |
| CC-MAIN-2024-10 | Binoculars not flagged | document | UnQover | 27251 | 2524 | 87.69 | 86.91 | 88.47 |
| CC-MAIN-2024-10 | Binoculars not flagged | document | RoBERTa | 27251 | 2524 | 86.02 | 85.42 | 86.56 |
| CC-MAIN-2024-10 | Binoculars not flagged | group paragraphs | SocialSent | 27251 | 2524 | 75.48 | 69.66 | 80.34 |
| CC-MAIN-2024-10 | Binoculars not flagged | group paragraphs | VADER | 27251 | 2524 | 74.25 | 71.12 | 77.12 |
| CC-MAIN-2024-10 | Binoculars not flagged | group paragraphs | UnQover | 27251 | 2524 | 80.87 | 75.36 | 85.37 |
| CC-MAIN-2024-10 | has marker word | document | SocialSent | 2094 | 236 | 84.53 | 82.41 | 86.54 |
| CC-MAIN-2024-10 | has marker word | document | VADER | 2094 | 236 | 84.91 | 83.72 | 86.15 |
| CC-MAIN-2024-10 | has marker word | document | UnQover | 2094 | 236 | 94.2 | 92.43 | 95.8 |
| CC-MAIN-2024-10 | has marker word | document | RoBERTa | 2094 | 236 | 93.92 | 92.82 | 94.85 |
| CC-MAIN-2024-10 | has marker word | group paragraphs | SocialSent | 2094 | 236 | 86.52 | 76.74 | 93.31 |
| CC-MAIN-2024-10 | has marker word | group paragraphs | VADER | 2094 | 236 | 81.72 | 74.25 | 87.11 |
| CC-MAIN-2024-10 | has marker word | group paragraphs | UnQover | 2094 | 236 | 87.3 | 77.77 | 94.87 |
| CC-MAIN-2024-10 | no marker word | document | SocialSent | 25364 | 2302 | 78.71 | 78.0 | 79.45 |
| CC-MAIN-2024-10 | no marker word | document | VADER | 25364 | 2302 | 77.64 | 77.21 | 78.11 |
| CC-MAIN-2024-10 | no marker word | document | UnQover | 25364 | 2302 | 87.12 | 86.26 | 87.92 |
| CC-MAIN-2024-10 | no marker word | document | RoBERTa | 25364 | 2302 | 85.2 | 84.63 | 85.78 |
| CC-MAIN-2024-10 | no marker word | group paragraphs | SocialSent | 25364 | 2302 | 74.2 | 68.22 | 79.44 |
| CC-MAIN-2024-10 | no marker word | group paragraphs | VADER | 25364 | 2302 | 73.43 | 70.13 | 76.64 |
| CC-MAIN-2024-10 | no marker word | group paragraphs | UnQover | 25364 | 2302 | 80.08 | 74.44 | 85.08 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | document | SocialSent | 184 | 10 | 85.49 | 76.49 | 92.33 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | document | VADER | 184 | 10 | 83.35 | 78.25 | 87.78 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | document | UnQover | 184 | 10 | 96.23 | 91.8 | 100.0 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | document | RoBERTa | 184 | 10 | 88.01 | 81.63 | 93.08 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | group paragraphs | SocialSent | 184 | 10 | 100.0 | 100.0 | 100.0 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | group paragraphs | VADER | 184 | 10 | 100.0 | 100.0 | 100.0 |
| CC-MAIN-2024-51 | Binoculars flagged (1% FPR) | group paragraphs | UnQover | 184 | 10 | nan | nan | nan |
| CC-MAIN-2024-51 | Binoculars not flagged | document | SocialSent | 22006 | 2040 | 80.88 | 80.17 | 81.62 |
| CC-MAIN-2024-51 | Binoculars not flagged | document | VADER | 22006 | 2040 | 79.52 | 79.04 | 79.93 |
| CC-MAIN-2024-51 | Binoculars not flagged | document | UnQover | 22006 | 2040 | 88.25 | 87.34 | 89.06 |
| CC-MAIN-2024-51 | Binoculars not flagged | document | RoBERTa | 22006 | 2040 | 87.06 | 86.45 | 87.63 |
| CC-MAIN-2024-51 | Binoculars not flagged | group paragraphs | SocialSent | 22006 | 2040 | 76.14 | 71.57 | 80.63 |
| CC-MAIN-2024-51 | Binoculars not flagged | group paragraphs | VADER | 22006 | 2040 | 73.49 | 70.08 | 76.52 |
| CC-MAIN-2024-51 | Binoculars not flagged | group paragraphs | UnQover | 22006 | 2040 | 75.56 | 69.43 | 81.97 |
| CC-MAIN-2024-51 | has marker word | document | SocialSent | 2152 | 222 | 87.58 | 86.07 | 89.16 |
| CC-MAIN-2024-51 | has marker word | document | VADER | 2152 | 222 | 86.22 | 85.15 | 87.37 |
| CC-MAIN-2024-51 | has marker word | document | UnQover | 2152 | 222 | 92.44 | 89.75 | 94.71 |
| CC-MAIN-2024-51 | has marker word | document | RoBERTa | 2152 | 222 | 94.88 | 93.94 | 95.8 |
| CC-MAIN-2024-51 | has marker word | group paragraphs | SocialSent | 2152 | 222 | 86.83 | 74.76 | 95.03 |
| CC-MAIN-2024-51 | has marker word | group paragraphs | VADER | 2152 | 222 | 85.57 | 78.4 | 91.3 |
| CC-MAIN-2024-51 | has marker word | group paragraphs | UnQover | 2152 | 222 | 82.26 | 60.0 | 100.0 |
| CC-MAIN-2024-51 | no marker word | document | SocialSent | 20038 | 1828 | 80.07 | 79.25 | 80.81 |
| CC-MAIN-2024-51 | no marker word | document | VADER | 20038 | 1828 | 78.63 | 78.17 | 79.08 |
| CC-MAIN-2024-51 | no marker word | document | UnQover | 20038 | 1828 | 87.79 | 86.92 | 88.66 |
| CC-MAIN-2024-51 | no marker word | document | RoBERTa | 20038 | 1828 | 85.96 | 85.29 | 86.59 |
| CC-MAIN-2024-51 | no marker word | group paragraphs | SocialSent | 20038 | 1828 | 74.73 | 70.3 | 79.27 |
| CC-MAIN-2024-51 | no marker word | group paragraphs | VADER | 20038 | 1828 | 72.25 | 68.88 | 75.51 |
| CC-MAIN-2024-51 | no marker word | group paragraphs | UnQover | 20038 | 1828 | 74.48 | 68.39 | 80.87 |

